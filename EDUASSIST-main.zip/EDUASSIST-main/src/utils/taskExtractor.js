import * as chrono from 'chrono-node';

const TASK_KEYWORDS = {
  assignment: [
    'assignment',
    'submit',
    'turn in',
    'complete',
    'finish',
    'work on',
    'do'
  ],
  homework: [
    'homework',
    'exercise',
    'practice',
    'worksheet',
    'problem set',
    'reading'
  ],
  project: [
    'project',
    'presentation',
    'group work',
    'research',
    'report',
    'essay'
  ]
};

export function extractTasks(transcript) {
  if (!transcript.trim()) return [];

  const sentences = transcript
    .split(/[.!?]+/)
    .map(s => s.trim())
    .filter(s => s.length > 0);

  const tasks = [];

  sentences.forEach((sentence) => {
    const lowercaseSentence = sentence.toLowerCase();
    
    // Check for task keywords
    for (const [type, keywords] of Object.entries(TASK_KEYWORDS)) {
      if (keywords.some(keyword => {
        // Match whole words only
        const regex = new RegExp(`\\b${keyword}\\b`, 'i');
        return regex.test(lowercaseSentence);
      })) {
        // Try to parse date using chrono
        const parsedDate = chrono.parseDate(sentence);
        
        // Clean up the title by removing common date-related phrases
        let title = sentence.trim();
        if (parsedDate) {
          const datePatterns = [
            /\b(due|by|on|before|after)\b.*$/i,
            /\b(next|this|coming)\s+(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b.*$/i,
            /\b\d{1,2}(st|nd|rd|th)?\s+(of\s+)?(january|february|march|april|may|june|july|august|september|october|november|december)\b.*$/i,
            /\b\d{1,2}\/\d{1,2}(\/\d{2,4})?\b.*$/i
          ];

          datePatterns.forEach(pattern => {
            title = title.replace(pattern, '').trim();
          });
        }

        tasks.push({
          id: Math.random().toString(36).substr(2, 9),
          title: title || sentence.trim(),
          dueDate: parsedDate,
          type,
          completed: false
        });
        break;
      }
    }
  });

  return tasks;
}