import React from 'react';
import { FileText } from 'lucide-react';

interface TranscriptViewProps {
  transcript: string;
}

export function TranscriptView({ transcript }: TranscriptViewProps) {
  if (!transcript) {
    return (
      <div className="flex flex-col items-center justify-center p-8 text-gray-400 bg-gray-50 rounded-lg">
        <FileText className="w-12 h-12 mb-2" />
        <p className="text-lg">Start recording to see the transcript</p>
      </div>
    );
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
        <FileText className="w-5 h-5" />
        Transcript
      </h2>
      <div className="prose max-w-none">
        <p className="whitespace-pre-wrap">{transcript}</p>
      </div>
    </div>
  );
}