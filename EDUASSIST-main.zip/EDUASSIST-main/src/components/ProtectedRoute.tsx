import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

interface ProtectedRouteProps {
  children: React.ReactNode;
  role: 'teacher' | 'student';
}

export default function ProtectedRoute({ children, role }: ProtectedRouteProps) {
  const { user, role: userRole } = useAuth();

  if (!user) {
    return <Navigate to="/login" />;
  }

  if (role !== userRole) {
    return <Navigate to="/login" />;
  }

  return <>{children}</>;
}