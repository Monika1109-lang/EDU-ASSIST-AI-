import React from 'react';
import { format } from 'date-fns';
import { CheckCircle2, Circle, Calendar } from 'lucide-react';
import { Task } from '../types';

interface TaskListProps {
  tasks: Task[];
  onToggleTask: (taskId: string) => void;
}

export function TaskList({ tasks, onToggleTask }: TaskListProps) {
  if (tasks.length === 0) {
    return (
      <div className="text-center p-8 bg-gray-50 rounded-lg">
        <p className="text-gray-500">No tasks detected yet</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {tasks.map((task) => (
        <div
          key={task.id}
          className={`flex items-start gap-4 p-4 rounded-lg border transition-colors ${
            task.completed ? 'bg-gray-50 border-gray-200' : 'bg-white border-gray-200'
          }`}
        >
          <button
            onClick={() => onToggleTask(task.id)}
            className="mt-1 text-blue-500 hover:text-blue-600 transition-colors"
          >
            {task.completed ? (
              <CheckCircle2 className="w-5 h-5" />
            ) : (
              <Circle className="w-5 h-5" />
            )}
          </button>
          <div className="flex-1">
            <p className={`text-gray-900 ${task.completed ? 'line-through' : ''}`}>
              {task.title}
            </p>
            {task.dueDate && (
              <p className="flex items-center gap-1 text-sm text-gray-500 mt-1">
                <Calendar className="w-4 h-4" />
                Due: {format(task.dueDate, 'PPP')}
              </p>
            )}
          </div>
          <span
            className={`px-2 py-1 text-xs font-medium rounded-full ${
              task.type === 'assignment'
                ? 'bg-blue-100 text-blue-700'
                : task.type === 'homework'
                ? 'bg-green-100 text-green-700'
                : 'bg-purple-100 text-purple-700'
            }`}
          >
            {task.type}
          </span>
        </div>
      ))}
    </div>
  );
}