import React from 'react';
import { Bell, X, Calendar } from 'lucide-react';
import { Task } from '../types';
import { format, isToday, isTomorrow, addDays } from 'date-fns';

interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'success';
  timestamp: Date;
}

interface NotificationCenterProps {
  notifications: Notification[];
  tasks: Task[];
  onDismiss: (id: string) => void;
}

export function NotificationCenter({ notifications, tasks, onDismiss }: NotificationCenterProps) {
  // Convert tasks to notifications
  const taskNotifications = tasks
    .filter(task => task.dueDate && !task.completed)
    .map(task => {
      const dueDate = task.dueDate as Date;
      let type: 'info' | 'warning' | 'success' = 'info';
      let message = '';

      if (isToday(dueDate)) {
        type = 'warning';
        message = 'Due today!';
      } else if (isTomorrow(dueDate)) {
        type = 'info';
        message = 'Due tomorrow';
      } else if (dueDate < new Date()) {
        type = 'warning';
        message = 'Overdue';
      } else if (dueDate <= addDays(new Date(), 3)) {
        type = 'info';
        message = `Due in ${format(dueDate, 'EEEE')}`;
      }

      return {
        id: `task-${task.id}`,
        title: task.title,
        message,
        type,
        timestamp: new Date(),
        dueDate
      };
    });

  const allNotifications = [...notifications, ...taskNotifications]
    .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());

  return (
    <div className="fixed top-16 right-4 w-80 max-w-sm z-50">
      <div className="space-y-2">
        {allNotifications.map((notification) => (
          <div
            key={notification.id}
            className={`p-4 rounded-lg shadow-lg bg-white border-l-4 ${
              notification.type === 'warning'
                ? 'border-orange-500'
                : notification.type === 'success'
                ? 'border-green-500'
                : 'border-blue-500'
            }`}
          >
            <div className="flex justify-between items-start">
              <div className="flex items-center">
                <Bell className="h-5 w-5 text-gray-600" />
                <span className="ml-2 font-medium text-gray-900">
                  {notification.title}
                </span>
              </div>
              <button
                onClick={() => onDismiss(notification.id)}
                className="text-gray-400 hover:text-gray-500"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <p className="mt-1 text-sm text-gray-600">{notification.message}</p>
            {'dueDate' in notification && (
              <div className="mt-2 flex items-center text-xs text-gray-500">
                <Calendar className="h-3 w-3 mr-1" />
                {format(notification.dueDate, 'PPP')}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}