import React from 'react';
import { BarChart, Card, Title } from '@tremor/react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const syllabusData = [
  {
    subject: "Mathematics",
    completed: 75,
    total: 100,
  },
  {
    subject: "Physics",
    completed: 60,
    total: 100,
  },
  {
    subject: "Chemistry",
    completed: 85,
    total: 100,
  },
  {
    subject: "Biology",
    completed: 45,
    total: 100,
  },
];

const progressData = [
  { month: 'Jan', progress: 30 },
  { month: 'Feb', progress: 45 },
  { month: 'Mar', progress: 60 },
  { month: 'Apr', progress: 75 },
  { month: 'May', progress: 85 },
];

export function SyllabusProgress() {
  return (
    <div className="space-y-6">
      <Card className="bg-white rounded-xl shadow-sm p-6">
        <Title className="text-lg font-serif font-semibold text-scholar-900">
          Subject-wise Syllabus Progress
        </Title>
        <BarChart
          className="mt-4 h-48"
          data={syllabusData}
          index="subject"
          categories={["completed"]}
          colors={["scholar"]}
        />
      </Card>

      <Card className="bg-white rounded-xl shadow-sm p-6">
        <Title className="text-lg font-serif font-semibold text-scholar-900">
          Overall Progress Trend
        </Title>
        <div className="h-48 mt-4">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={progressData}>
              <CartesianGrid strokeDasharray="3 3" className="text-scholar-200" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Area
                type="monotone"
                dataKey="progress"
                stroke="#16a34a"
                fill="#16a34a"
                fillOpacity={0.2}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </Card>
    </div>
  );
}