import React from 'react';
import PropTypes from 'prop-types';
import { GraduationCap, LogOut, User, Bell, Settings } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

export function Header({ title }) {
  const { user, role, signOut } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    try {
      await signOut();
      navigate('/login');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  return (
    <nav className="bg-white shadow-sm border-b sticky top-0 z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <GraduationCap className="h-8 w-8 text-indigo-600" />
            <span className="ml-2 text-xl font-semibold text-gray-900">
              {title}
            </span>
          </div>
          <div className="flex items-center space-x-4">
            <button className="p-2 rounded-full hover:bg-gray-100 relative">
              <Bell className="h-5 w-5 text-gray-500" />
              <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-red-400 ring-2 ring-white" />
            </button>
            <div className="flex items-center space-x-2">
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900">{user?.email}</p>
                <p className="text-xs text-gray-500 capitalize">{role}</p>
              </div>
              <User className="h-8 w-8 text-gray-500 bg-gray-100 rounded-full p-1" />
            </div>
            {role === 'teacher' && (
              <button
                onClick={() => {/* Add settings handler */}}
                className="p-2 rounded-full hover:bg-gray-100"
                title="Settings"
              >
                <Settings className="h-5 w-5 text-gray-500" />
              </button>
            )}
            <button
              onClick={handleSignOut}
              className="p-2 rounded-full hover:bg-gray-100"
              title="Sign out"
            >
              <LogOut className="h-5 w-5 text-gray-500" />
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}

Header.propTypes = {
  title: PropTypes.string.isRequired
};