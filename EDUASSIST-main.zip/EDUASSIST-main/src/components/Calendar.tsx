import React from 'react';
import Calendar from 'react-calendar';
import { format } from 'date-fns';
import { Bell, CalendarDays } from 'lucide-react';
import { Task } from '../types';
import 'react-calendar/dist/Calendar.css';

interface Event {
  date: Date;
  title: string;
  type: 'assignment' | 'exam' | 'reminder' | Task['type'];
}

interface CustomCalendarProps {
  events: Event[];
  onDateSelect: (date: Date) => void;
  tasks?: Task[];
}

export function CustomCalendar({ events, onDateSelect, tasks = [] }: CustomCalendarProps) {
  // Combine events and tasks
  const allEvents = [
    ...events,
    ...tasks.map(task => ({
      date: task.dueDate || new Date(),
      title: task.title,
      type: task.type
    }))
  ];

  const tileContent = ({ date }: { date: Date }) => {
    const dayEvents = allEvents.filter(
      event => format(event.date, 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd')
    );

    if (dayEvents.length === 0) return null;

    return (
      <div className="absolute bottom-0 right-0 flex gap-1">
        {dayEvents.map((event, index) => (
          <div
            key={index}
            className={`h-2 w-2 rounded-full ${
              event.type === 'assignment'
                ? 'bg-blue-500'
                : event.type === 'homework'
                ? 'bg-green-500'
                : event.type === 'project'
                ? 'bg-purple-500'
                : 'bg-gray-500'
            }`}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="p-4 bg-white rounded-xl shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-gray-900">Calendar</h2>
        <CalendarDays className="h-5 w-5 text-gray-500" />
      </div>
      
      <Calendar
        onChange={onDateSelect}
        tileContent={tileContent}
        className="rounded-lg border-none w-full"
        tileClassName={({ date }) => {
          const hasEvents = allEvents.some(
            event => format(event.date, 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd')
          );
          return hasEvents ? 'bg-gray-50 text-gray-900 relative' : 'relative';
        }}
      />
      
      <div className="mt-4 space-y-2">
        <h3 className="font-medium text-gray-900">Upcoming Events</h3>
        {allEvents
          .filter(event => event.date >= new Date())
          .sort((a, b) => a.date.getTime() - b.date.getTime())
          .slice(0, 3)
          .map((event, index) => (
            <div
              key={index}
              className={`flex items-center justify-between p-2 rounded-lg ${
                event.type === 'assignment'
                  ? 'bg-blue-50 text-blue-700'
                  : event.type === 'homework'
                  ? 'bg-green-50 text-green-700'
                  : event.type === 'project'
                  ? 'bg-purple-50 text-purple-700'
                  : 'bg-gray-50 text-gray-700'
              }`}
            >
              <div className="flex items-center gap-2">
                <Bell className="h-4 w-4" />
                <span className="text-sm">{event.title}</span>
              </div>
              <span className="text-xs">
                {format(event.date, 'MMM dd')}
              </span>
            </div>
          ))}
      </div>
    </div>
  );
}