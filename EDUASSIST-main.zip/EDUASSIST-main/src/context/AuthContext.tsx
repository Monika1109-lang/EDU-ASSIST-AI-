import React, { createContext, useContext, useState } from 'react';

interface User {
  email: string;
  id: string;
}

interface AuthContextType {
  user: User | null;
  role: 'teacher' | 'student' | null;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock users for demonstration
const MOCK_USERS = [
  { email: 'teacher@eduassist.com', password: 'teacher123', role: 'teacher' },
  { email: 'student@eduassist.com', password: 'student123', role: 'student' }
];

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [role, setRole] = useState<'teacher' | 'student' | null>(null);

  async function signIn(email: string, password: string) {
    const mockUser = MOCK_USERS.find(u => u.email === email && u.password === password);
    
    if (!mockUser) {
      throw new Error('Invalid credentials');
    }

    const newUser = {
      email: mockUser.email,
      id: btoa(mockUser.email) // Simple way to generate a consistent ID
    };

    setUser(newUser);
    setRole(mockUser.role as 'teacher' | 'student');
  }

  async function signOut() {
    setUser(null);
    setRole(null);
  }

  const value = {
    user,
    role,
    signIn,
    signOut
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}