import React, { createContext, useContext, useState } from 'react';
import PropTypes from 'prop-types';

const AuthContext = createContext(undefined);

// Mock users for demonstration
const MOCK_USERS = [
  { email: 'teacher@example.com', password: 'password123', role: 'teacher' },
  { email: 'student@example.com', password: 'password123', role: 'student' }
];

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [role, setRole] = useState(null);

  async function signIn(email, password) {
    const mockUser = MOCK_USERS.find(u => u.email === email && u.password === password);
    
    if (!mockUser) {
      throw new Error('Invalid credentials');
    }

    const newUser = {
      email: mockUser.email,
      id: btoa(mockUser.email) // Simple way to generate a consistent ID
    };

    setUser(newUser);
    setRole(mockUser.role);
  }

  async function signOut() {
    setUser(null);
    setRole(null);
  }

  const value = {
    user,
    role,
    signIn,
    signOut
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

AuthProvider.propTypes = {
  children: PropTypes.node.isRequired
};

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}