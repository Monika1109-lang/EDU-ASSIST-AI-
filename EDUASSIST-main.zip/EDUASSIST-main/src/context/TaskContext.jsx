import React, { createContext, useContext, useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { useAuth } from './AuthContext';

const TaskContext = createContext(undefined);

// Simulated shared task storage
let globalTasks = [];

export function TaskProvider({ children }) {
  const [tasks, setTasks] = useState([]);
  const { role } = useAuth();

  // Initialize tasks
  useEffect(() => {
    setTasks(globalTasks);
  }, []);

  const addTask = (task) => {
    const newTask = {
      ...task,
      id: Math.random().toString(36).substr(2, 9),
      createdAt: new Date(),
      completed: false
    };
    globalTasks = [...globalTasks, newTask];
    setTasks(globalTasks);
  };

  const toggleTask = (taskId) => {
    globalTasks = globalTasks.map(task =>
      task.id === taskId ? { ...task, completed: !task.completed } : task
    );
    setTasks(globalTasks);
  };

  const value = {
    tasks,
    addTask: role === 'teacher' ? addTask : undefined,
    toggleTask
  };

  return <TaskContext.Provider value={value}>{children}</TaskContext.Provider>;
}

TaskProvider.propTypes = {
  children: PropTypes.node.isRequired
};

export function useTasks() {
  const context = useContext(TaskContext);
  if (context === undefined) {
    throw new Error('useTasks must be used within a TaskProvider');
  }
  return context;
}