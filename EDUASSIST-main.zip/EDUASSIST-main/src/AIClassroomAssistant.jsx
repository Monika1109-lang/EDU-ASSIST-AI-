import React, { useState, useEffect, useCallback, useRef } from 'react';
import { format } from 'date-fns';
import { GraduationCap, Mic, MicOff, CheckCircle2, Circle, Calendar, FileText } from 'lucide-react';
import * as chrono from 'chrono-node';

// Task Keywords and Types
const TASK_KEYWORDS = {
  assignment: ['assignment', 'submit', 'turn in', 'complete', 'finish', 'work on', 'do'],
  homework: ['homework', 'exercise', 'practice', 'worksheet', 'problem set', 'reading'],
  project: ['project', 'presentation', 'group work', 'research', 'report', 'essay']
};

// Task Extractor Function
function extractTasks(transcript) {
  if (!transcript.trim()) return [];

  const sentences = transcript
    .split(/[.!?]+/)
    .map(s => s.trim())
    .filter(s => s.length > 0);

  const tasks = [];

  sentences.forEach((sentence) => {
    const lowercaseSentence = sentence.toLowerCase();
    
    for (const [type, keywords] of Object.entries(TASK_KEYWORDS)) {
      if (keywords.some(keyword => {
        const regex = new RegExp(`\\b${keyword}\\b`, 'i');
        return regex.test(lowercaseSentence);
      })) {
        const parsedDate = chrono.parseDate(sentence);
        
        let title = sentence.trim();
        if (parsedDate) {
          const datePatterns = [
            /\b(due|by|on|before|after)\b.*$/i,
            /\b(next|this|coming)\s+(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b.*$/i,
            /\b\d{1,2}(st|nd|rd|th)?\s+(of\s+)?(january|february|march|april|may|june|july|august|september|october|november|december)\b.*$/i,
            /\b\d{1,2}\/\d{1,2}(\/\d{2,4})?\b.*$/i
          ];

          datePatterns.forEach(pattern => {
            title = title.replace(pattern, '').trim();
          });
        }

        tasks.push({
          id: Math.random().toString(36).substr(2, 9),
          title: title || sentence.trim(),
          dueDate: parsedDate,
          type,
          completed: false
        });
        break;
      }
    }
  });

  return tasks;
}

// Speech Recognition Hook
function useSpeechRecognition() {
  const [isRecording, setIsRecording] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [error, setError] = useState(null);
  const recognitionRef = useRef(null);

  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setError('Speech recognition is not supported in this browser.');
      return;
    }

    recognitionRef.current = new SpeechRecognition();
    const recognition = recognitionRef.current;
    
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onresult = (event) => {
      let finalTranscript = '';
      let interimTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          finalTranscript += transcript + ' ';
        } else {
          interimTranscript += transcript;
        }
      }

      if (finalTranscript) {
        setTranscript(prev => prev + finalTranscript);
      }
    };

    recognition.onerror = (event) => {
      setError(event.error);
      setIsRecording(false);
    };

    return () => {
      if (recognition) {
        recognition.stop();
      }
    };
  }, []);

  const startRecording = useCallback(() => {
    if (!recognitionRef.current) {
      setError('Speech recognition is not supported.');
      return;
    }

    try {
      setIsRecording(true);
      setError(null);
      recognitionRef.current.start();
    } catch (err) {
      setError('Failed to start recording. Please try again.');
      setIsRecording(false);
    }
  }, []);

  const stopRecording = useCallback(() => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
    setIsRecording(false);
  }, []);

  return { isRecording, transcript, error, startRecording, stopRecording };
}

// Components
function RecordButton({ isRecording, onStart, onStop }) {
  return (
    <button
      onClick={isRecording ? onStop : onStart}
      className={`flex items-center justify-center gap-2 px-6 py-3 rounded-full text-white font-medium transition-all ${
        isRecording 
          ? 'bg-red-500 hover:bg-red-600 animate-pulse' 
          : 'bg-blue-500 hover:bg-blue-600'
      }`}
    >
      {isRecording ? (
        <>
          <MicOff className="w-5 h-5" />
          Stop Recording
        </>
      ) : (
        <>
          <Mic className="w-5 h-5" />
          Start Recording
        </>
      )}
    </button>
  );
}

function TranscriptView({ transcript }) {
  if (!transcript) {
    return (
      <div className="flex flex-col items-center justify-center p-8 text-gray-400 bg-gray-50 rounded-lg">
        <FileText className="w-12 h-12 mb-2" />
        <p className="text-lg">Start recording to see the transcript</p>
      </div>
    );
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
        <FileText className="w-5 h-5" />
        Transcript
      </h2>
      <div className="prose max-w-none">
        <p className="whitespace-pre-wrap">{transcript}</p>
      </div>
    </div>
  );
}

function TaskList({ tasks, onToggleTask }) {
  if (tasks.length === 0) {
    return (
      <div className="text-center p-8 bg-gray-50 rounded-lg">
        <p className="text-gray-500">No tasks detected yet</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {tasks.map((task) => (
        <div
          key={task.id}
          className={`flex items-start gap-4 p-4 rounded-lg border transition-colors ${
            task.completed ? 'bg-gray-50 border-gray-200' : 'bg-white border-gray-200'
          }`}
        >
          <button
            onClick={() => onToggleTask(task.id)}
            className="mt-1 text-blue-500 hover:text-blue-600 transition-colors"
          >
            {task.completed ? (
              <CheckCircle2 className="w-5 h-5" />
            ) : (
              <Circle className="w-5 h-5" />
            )}
          </button>
          <div className="flex-1">
            <p className={`text-gray-900 ${task.completed ? 'line-through' : ''}`}>
              {task.title}
            </p>
            {task.dueDate && (
              <p className="flex items-center gap-1 text-sm text-gray-500 mt-1">
                <Calendar className="w-4 h-4" />
                Due: {format(task.dueDate, 'PPP')}
              </p>
            )}
          </div>
          <span
            className={`px-2 py-1 text-xs font-medium rounded-full ${
              task.type === 'assignment'
                ? 'bg-blue-100 text-blue-700'
                : task.type === 'homework'
                ? 'bg-green-100 text-green-700'
                : 'bg-purple-100 text-purple-700'
            }`}
          >
            {task.type}
          </span>
        </div>
      ))}
    </div>
  );
}

// Main App Component
export default function AIClassroomAssistant() {
  const { isRecording, transcript, error, startRecording, stopRecording } = useSpeechRecognition();
  const [tasks, setTasks] = useState([]);

  useEffect(() => {
    const newTasks = extractTasks(transcript);
    setTasks(prev => [...prev, ...newTasks]);
  }, [transcript]);

  const handleToggleTask = (taskId) => {
    setTasks(prev =>
      prev.map(task =>
        task.id === taskId ? { ...task, completed: !task.completed } : task
      )
    );
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center gap-2">
            <GraduationCap className="w-8 h-8 text-blue-500" />
            <h1 className="text-2xl font-bold text-gray-900">AI Classroom Assistant</h1>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid gap-8">
          <div className="flex justify-center">
            <RecordButton
              isRecording={isRecording}
              onStart={startRecording}
              onStop={stopRecording}
            />
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
              {error}
            </div>
          )}

          <div className="grid gap-8 md:grid-cols-2">
            <section>
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Live Transcript</h2>
              <TranscriptView transcript={transcript} />
            </section>

            <section>
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Detected Tasks</h2>
              <TaskList tasks={tasks} onToggleTask={handleToggleTask} />
            </section>
          </div>
        </div>
      </main>
    </div>
  );
}