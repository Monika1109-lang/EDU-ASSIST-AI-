import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  GraduationCap, LogOut, User, Settings, Bell, Calendar as CalendarIcon, CheckCircle2, 
  Users, FileText, Phone, History, CalendarDays, BookOpen, Search, Filter
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useSpeechRecognition } from '../hooks/useSpeechRecognition';
import { RecordButton } from '../components/RecordButton';
import { TranscriptView } from '../components/TranscriptView';
import { TaskList } from '../components/TaskList';
import { CustomCalendar } from '../components/Calendar';
import { Task } from '../types';
import { extractTasks } from '../utils/taskExtractor';
import { format, addDays } from 'date-fns';
import clsx from 'clsx';

// Enhanced mock data
const MOCK_STUDENTS = [
  { id: 1, name: 'John Doe', grade: '10th', attendance: { present: 15, absent: 2, late: 1 } },
  { id: 2, name: 'Jane Smith', grade: '10th', attendance: { present: 16, absent: 1, late: 1 } },
  { id: 3, name: 'Mike Johnson', grade: '10th', attendance: { present: 14, absent: 3, late: 1 } },
  { id: 4, name: 'Sarah Williams', grade: '10th', attendance: { present: 17, absent: 0, late: 1 } },
  { id: 5, name: 'Tom Brown', grade: '10th', attendance: { present: 15, absent: 2, late: 1 } },
];

const MOCK_ATTENDANCE_DATES = [
  { date: '2024-03-10', records: MOCK_STUDENTS.map(s => ({ ...s, status: Math.random() > 0.1 ? 'present' : 'absent' })) },
  { date: '2024-03-11', records: MOCK_STUDENTS.map(s => ({ ...s, status: Math.random() > 0.1 ? 'present' : 'absent' })) },
  { date: '2024-03-12', records: MOCK_STUDENTS.map(s => ({ ...s, status: Math.random() > 0.1 ? 'present' : 'absent' })) },
];

const MOCK_EVENTS = [
  { date: addDays(new Date(), 2), title: 'Parent-Teacher Meeting', type: 'meeting' as const },
  { date: addDays(new Date(), 5), title: 'Science Fair', type: 'event' as const },
];

export default function TeacherDashboard() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const { isRecording, transcript, error, startRecording, stopRecording, clearTranscript } = useSpeechRecognition();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [activeTab, setActiveTab] = useState<'tasks' | 'attendance' | 'calendar'>('tasks');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [attendanceFilter, setAttendanceFilter] = useState<'all' | 'present' | 'absent'>('all');

  useEffect(() => {
    const newTasks = extractTasks(transcript);
    if (newTasks.length > 0) {
      setTasks(prev => [...prev, ...newTasks]);
    }
  }, [transcript]);

  const handleStopRecording = () => {
    stopRecording();
    clearTranscript();
  };

  const handleToggleTask = (taskId: string) => {
    setTasks(prev =>
      prev.map(task =>
        task.id === taskId ? { ...task, completed: !task.completed } : task
      )
    );
  };

  const handleSignOut = async () => {
    try {
      await signOut();
      navigate('/login');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  const filteredStudents = MOCK_STUDENTS.filter(student => 
    student.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const renderAttendanceTab = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search students..."
            className="pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setAttendanceFilter('all')}
            className={clsx(
              'px-4 py-2 rounded-lg text-sm font-medium',
              attendanceFilter === 'all'
                ? 'bg-blue-100 text-blue-700'
                : 'text-gray-600 hover:bg-gray-100'
            )}
          >
            All
          </button>
          <button
            onClick={() => setAttendanceFilter('present')}
            className={clsx(
              'px-4 py-2 rounded-lg text-sm font-medium',
              attendanceFilter === 'present'
                ? 'bg-green-100 text-green-700'
                : 'text-gray-600 hover:bg-gray-100'
            )}
          >
            Present
          </button>
          <button
            onClick={() => setAttendanceFilter('absent')}
            className={clsx(
              'px-4 py-2 rounded-lg text-sm font-medium',
              attendanceFilter === 'absent'
                ? 'bg-red-100 text-red-700'
                : 'text-gray-600 hover:bg-gray-100'
            )}
          >
            Absent
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Student
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Grade
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Attendance Rate
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredStudents.map((student) => (
              <tr key={student.id}>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="h-10 w-10 flex-shrink-0">
                      <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
                        <span className="text-gray-600 font-medium">
                          {student.name.split(' ').map(n => n[0]).join('')}
                        </span>
                      </div>
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-gray-900">{student.name}</div>
                      <div className="text-sm text-gray-500">ID: {student.id}</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">{student.grade}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="flex-1 bg-gray-200 rounded-full h-2 mr-2">
                      <div
                        className="bg-green-500 h-2 rounded-full"
                        style={{
                          width: `${(student.attendance.present / (student.attendance.present + student.attendance.absent + student.attendance.late)) * 100}%`
                        }}
                      />
                    </div>
                    <span className="text-sm text-gray-500">
                      {Math.round((student.attendance.present / (student.attendance.present + student.attendance.absent + student.attendance.late)) * 100)}%
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={clsx(
                    'px-2 py-1 text-xs font-medium rounded-full',
                    Math.random() > 0.1
                      ? 'bg-green-100 text-green-800'
                      : 'bg-red-100 text-red-800'
                  )}>
                    {Math.random() > 0.1 ? 'Present' : 'Absent'}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  <button className="text-blue-600 hover:text-blue-800">View Details</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white shadow-sm border-b sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <GraduationCap className="h-8 w-8 text-indigo-600" />
              <span className="ml-2 text-xl font-semibold text-gray-900">
                Teacher Dashboard
              </span>
            </div>
            <div className="flex items-center space-x-4">
              <button className="p-2 rounded-full hover:bg-gray-100 relative">
                <Bell className="h-5 w-5 text-gray-500" />
                <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-red-400 ring-2 ring-white" />
              </button>
              <div className="flex items-center space-x-2">
                <div className="text-right">
                  <p className="text-sm font-medium text-gray-900">{user?.email}</p>
                  <p className="text-xs text-gray-500">Teacher</p>
                </div>
                <User className="h-8 w-8 text-gray-500 bg-gray-100 rounded-full p-1" />
              </div>
              <button
                onClick={() => {/* Add settings handler */}}
                className="p-2 rounded-full hover:bg-gray-100"
                title="Settings"
              >
                <Settings className="h-5 w-5 text-gray-500" />
              </button>
              <button
                onClick={handleSignOut}
                className="p-2 rounded-full hover:bg-gray-100"
                title="Sign out"
              >
                <LogOut className="h-5 w-5 text-gray-500" />
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Voice Recognition</h2>
              <div className="flex justify-center mb-6">
                <RecordButton
                  isRecording={isRecording}
                  onStart={startRecording}
                  onStop={handleStopRecording}
                />
              </div>
              {error && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4">
                  {error}
                </div>
              )}
              <TranscriptView transcript={transcript} />
            </div>

            <div className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-gray-900">Dashboard</h2>
                <div className="flex space-x-2">
                  <button
                    onClick={() => setActiveTab('tasks')}
                    className={clsx(
                      'px-4 py-2 rounded-lg text-sm font-medium',
                      activeTab === 'tasks'
                        ? 'bg-blue-100 text-blue-700'
                        : 'text-gray-600 hover:bg-gray-100'
                    )}
                  >
                    Tasks
                  </button>
                  <button
                    onClick={() => setActiveTab('attendance')}
                    className={clsx(
                      'px-4 py-2 rounded-lg text-sm font-medium',
                      activeTab === 'attendance'
                        ? 'bg-blue-100 text-blue-700'
                        : 'text-gray-600 hover:bg-gray-100'
                    )}
                  >
                    Attendance
                  </button>
                  <button
                    onClick={() => setActiveTab('calendar')}
                    className={clsx(
                      'px-4 py-2 rounded-lg text-sm font-medium',
                      activeTab === 'calendar'
                        ? 'bg-blue-100 text-blue-700'
                        : 'text-gray-600 hover:bg-gray-100'
                    )}
                  >
                    Calendar
                  </button>
                </div>
              </div>

              {activeTab === 'tasks' && <TaskList tasks={tasks} onToggleTask={handleToggleTask} />}
              {activeTab === 'attendance' && renderAttendanceTab()}
              {activeTab === 'calendar' && (
                <CustomCalendar
                  events={MOCK_EVENTS}
                  tasks={tasks}
                  onDateSelect={(date) => setSelectedDate(date)}
                />
              )}
            </div>
          </div>

          <div className="space-y-8">
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Stats</h2>
              <div className="space-y-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-blue-700">Total Students</span>
                    <span className="text-2xl font-bold text-blue-700">{MOCK_STUDENTS.length}</span>
                  </div>
                </div>
                <div className="bg-green-50 p-4 rounded-lg">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-green-700">Present Today</span>
                    <span className="text-2xl font-bold text-green-700">
                      {MOCK_STUDENTS.filter(() => Math.random() > 0.1).length}
                    </span>
                  </div>
                </div>
                <div className="bg-orange-50 p-4 rounded-lg">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-orange-700">Tasks Created</span>
                    <span className="text-2xl font-bold text-orange-700">{tasks.length}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Upcoming Events</h2>
              <div className="space-y-4">
                {MOCK_EVENTS.map((event, index) => (
                  <div key={index} className="flex items-start space-x-4 p-3 bg-gray-50 rounded-lg">
                    <CalendarIcon className="h-5 w-5 text-indigo-600 mt-1" />
                    <div>
                      <h3 className="font-medium text-gray-900">{event.title}</h3>
                      <p className="text-sm text-gray-500">{format(event.date, 'PPP')}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}