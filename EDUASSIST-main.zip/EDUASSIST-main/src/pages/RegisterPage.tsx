import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { GraduationCap, BookOpen, ClipboardCheck as ChalkboardTeacher } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import clsx from 'clsx';

export default function RegisterPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedRole, setSelectedRole] = useState<'student' | 'teacher'>('student');
  const navigate = useNavigate();
  const { signIn } = useAuth();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    if (password !== confirmPassword) {
      setError('Passwords do not match');
      setIsLoading(false);
      return;
    }

    try {
      await signIn(email, password);
      navigate(selectedRole === 'teacher' ? '/teacher' : '/student');
    } catch (err) {
      setError('Failed to register. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-scholar-100 via-mint-100 to-pastel-blue">
      <div className="max-w-md w-full space-y-8 bg-white/95 backdrop-blur-sm p-8 rounded-2xl shadow-xl">
        <div className="text-center">
          <div className="flex justify-center">
            <GraduationCap className="h-12 w-12 text-scholar-600" />
          </div>
          <h2 className="mt-6 text-3xl font-serif font-bold text-scholar-950">
            Create your account
          </h2>
          <p className="mt-2 text-sm text-scholar-700 font-serif">
            Join ScholarSoft today
          </p>
        </div>

        <div className="flex gap-4 p-1 bg-scholar-50 rounded-lg">
          <button
            onClick={() => setSelectedRole('student')}
            className={clsx(
              'flex-1 flex items-center justify-center gap-2 py-2 px-4 rounded-md transition-all',
              selectedRole === 'student'
                ? 'bg-white shadow text-scholar-700'
                : 'text-scholar-600 hover:text-scholar-700'
            )}
          >
            <BookOpen className="w-4 h-4" />
            Student
          </button>
          <button
            onClick={() => setSelectedRole('teacher')}
            className={clsx(
              'flex-1 flex items-center justify-center gap-2 py-2 px-4 rounded-md transition-all',
              selectedRole === 'teacher'
                ? 'bg-white shadow text-scholar-700'
                : 'text-scholar-600 hover:text-scholar-700'
            )}
          >
            <ChalkboardTeacher className="w-4 h-4" />
            Teacher
          </button>
        </div>

        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          {error && (
            <div className="bg-pastel-red bg-opacity-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
              {error}
            </div>
          )}

          <div className="space-y-4">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-scholar-900">
                Email address
              </label>
              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="mt-1 block w-full px-3 py-2 border border-scholar-200 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-scholar-500 focus:border-scholar-500"
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-scholar-900">
                Password
              </label>
              <input
                id="password"
                name="password"
                type="password"
                autoComplete="new-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="mt-1 block w-full px-3 py-2 border border-scholar-200 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-scholar-500 focus:border-scholar-500"
              />
            </div>

            <div>
              <label htmlFor="confirmPassword" className="block text-sm font-medium text-scholar-900">
                Confirm Password
              </label>
              <input
                id="confirmPassword"
                name="confirmPassword"
                type="password"
                autoComplete="new-password"
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="mt-1 block w-full px-3 py-2 border border-scholar-200 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-scholar-500 focus:border-scholar-500"
              />
            </div>
          </div>

          <div>
            <button
              type="submit"
              disabled={isLoading}
              className="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-scholar-600 hover:bg-scholar-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-scholar-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {isLoading ? 'Creating account...' : 'Create account'}
            </button>
          </div>

          <div className="text-center">
            <p className="text-sm text-scholar-600">
              Already have an account?{' '}
              <Link to="/login" className="font-medium text-scholar-700 hover:text-scholar-800">
                Sign in
              </Link>
            </p>
          </div>
        </form>
      </div>
    </div>
  );
}