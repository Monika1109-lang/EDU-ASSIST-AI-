import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  GraduationCap, LogOut, User, Calendar as CalendarIcon, Clock, Bell, BookOpen, 
  CheckCircle2, FileText, Download, CalendarDays
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { format, isAfter, isBefore, addDays } from 'date-fns';
import { Task } from '../types';
import { CustomCalendar } from '../components/Calendar';
import { NotificationCenter } from '../components/NotificationCenter';
import clsx from 'clsx';

const MOCK_RESOURCES = [
  { id: 1, title: 'Mathematics Textbook', type: 'PDF', size: '5.2 MB', url: '#' },
  { id: 2, title: 'Physics Lab Manual', type: 'PDF', size: '3.8 MB', url: '#' },
  { id: 3, title: 'Chemistry Notes', type: 'PDF', size: '2.1 MB', url: '#' },
];

const MOCK_EVENTS = [
  { id: 1, title: 'Math Quiz', date: '2024-03-15', time: '09:00' },
  { id: 2, title: 'Science Fair', date: '2024-03-20', time: '10:00' },
];

function TaskCard({ task }: { task: Task }) {
  const getStatusColor = () => {
    if (!task.dueDate) return 'bg-gray-100 text-gray-700';
    
    const now = new Date();
    const tomorrow = addDays(now, 1);
    const nextWeek = addDays(now, 7);

    if (isBefore(task.dueDate, now)) return 'bg-red-100 text-red-700';
    if (isBefore(task.dueDate, tomorrow)) return 'bg-orange-100 text-orange-700';
    if (isBefore(task.dueDate, nextWeek)) return 'bg-yellow-100 text-yellow-700';
    return 'bg-green-100 text-green-700';
  };

  const getStatusText = () => {
    if (!task.dueDate) return 'No due date';
    
    const now = new Date();
    const tomorrow = addDays(now, 1);

    if (isBefore(task.dueDate, now)) return 'Overdue';
    if (isBefore(task.dueDate, tomorrow)) return 'Due Today';
    return 'Upcoming';
  };

  return (
    <div className="bg-white rounded-xl shadow-sm p-4 border border-gray-100 hover:border-indigo-100 transition-colors">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <h3 className="text-lg font-medium text-gray-900">{task.title}</h3>
          {task.dueDate && (
            <p className="flex items-center gap-1 text-sm text-gray-500 mt-1">
              <CalendarIcon className="w-4 h-4" />
              Due: {format(task.dueDate, 'PPP')}
            </p>
          )}
        </div>
        <span className={clsx(
          'px-2 py-1 text-xs font-medium rounded-full',
          getStatusColor()
        )}>
          {getStatusText()}
        </span>
      </div>
    </div>
  );
}

interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'success';
  timestamp: Date;
}

export default function StudentDashboard() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState<'tasks' | 'resources'>('tasks');
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);

  const tasks: Task[] = [
    {
      id: '1',
      title: 'Math Homework - Chapter 5',
      dueDate: addDays(new Date(), 1),
      type: 'homework',
      completed: false
    },
    {
      id: '2',
      title: 'Science Project - Solar System',
      dueDate: addDays(new Date(), 5),
      type: 'project',
      completed: false
    },
    {
      id: '3',
      title: 'English Essay',
      dueDate: addDays(new Date(), -1),
      type: 'assignment',
      completed: false
    }
  ];

  const events = [
    {
      date: addDays(new Date(), 2),
      title: 'Math Quiz',
      type: 'exam' as const
    },
    {
      date: addDays(new Date(), 5),
      title: 'Science Fair',
      type: 'reminder' as const
    }
  ];

  const handleDateSelect = (date: Date) => {
    const dayEvents = [...events, ...tasks].filter(
      event => format(event.date || event.dueDate!, 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd')
    );
    
    if (dayEvents.length > 0) {
      setNotifications(prev => [
        {
          id: Math.random().toString(),
          title: 'Events for ' + format(date, 'MMMM d'),
          message: `You have ${dayEvents.length} events scheduled`,
          type: 'info',
          timestamp: new Date()
        },
        ...prev
      ]);
    }
  };

  const dismissNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const handleSignOut = async () => {
    try {
      await signOut();
      navigate('/login');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white shadow-sm border-b sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <GraduationCap className="h-8 w-8 text-indigo-600" />
              <span className="ml-2 text-xl font-semibold text-gray-900">
                Student Dashboard
              </span>
            </div>
            <div className="flex items-center space-x-4">
              <button 
                className="p-2 rounded-full hover:bg-gray-100 relative"
                onClick={() => setShowNotifications(!showNotifications)}
              >
                <Bell className="h-5 w-5 text-gray-500" />
                {notifications.length > 0 && (
                  <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-red-400 ring-2 ring-white" />
                )}
              </button>
              <div className="flex items-center space-x-2">
                <div className="text-right">
                  <p className="text-sm font-medium text-gray-900">{user?.email}</p>
                  <p className="text-xs text-gray-500">Student</p>
                </div>
                <User className="h-8 w-8 text-gray-500 bg-gray-100 rounded-full p-1" />
              </div>
              <button
                onClick={handleSignOut}
                className="p-2 rounded-full hover:bg-gray-100"
                title="Sign out"
              >
                <LogOut className="h-5 w-5 text-gray-500" />
              </button>
            </div>
          </div>
        </div>
      </nav>

      {showNotifications && (
        <NotificationCenter
          notifications={notifications}
          tasks={tasks}
          onDismiss={dismissNotification}
        />
      )}

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8 grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <CustomCalendar
              events={events}
              tasks={tasks}
              onDateSelect={handleDateSelect}
            />
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Upcoming Events</h2>
            <div className="space-y-4">
              {MOCK_EVENTS.map((event) => (
                <div key={event.id} className="flex items-start space-x-4 p-3 bg-gray-50 rounded-lg">
                  <CalendarIcon className="h-5 w-5 text-indigo-600 mt-1" />
                  <div>
                    <h3 className="font-medium text-gray-900">{event.title}</h3>
                    <p className="text-sm text-gray-500">{event.date} at {event.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-indigo-900">Due Today</h2>
              <Clock className="h-5 w-5 text-indigo-500" />
            </div>
            <p className="text-3xl font-bold text-indigo-600">
              {tasks.filter(task => task.dueDate && isBefore(task.dueDate, addDays(new Date(), 1))).length}
            </p>
          </div>
          
          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-orange-900">This Week</h2>
              <CalendarIcon className="h-5 w-5 text-orange-500" />
            </div>
            <p className="text-3xl font-bold text-orange-600">
              {tasks.filter(task => task.dueDate && isBefore(task.dueDate, addDays(new Date(), 7))).length}
            </p>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-red-900">Overdue</h2>
              <Clock className="h-5 w-5 text-red-500" />
            </div>
            <p className="text-3xl font-bold text-red-600">
              {tasks.filter(task => task.dueDate && isBefore(task.dueDate, new Date())).length}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex items-center justify-between mb-6">
                <div className="flex space-x-4">
                  <button
                    onClick={() => setActiveSection('tasks')}
                    className={`flex items-center space-x-2 px-4 py-2 rounded-lg ${
                      activeSection === 'tasks'
                        ? 'bg-indigo-100 text-indigo-700'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    <CheckCircle2 className="h-5 w-5" />
                    <span>Tasks</span>
                  </button>
                  <button
                    onClick={() => setActiveSection('resources')}
                    className={`flex items-center space-x-2 px-4 py-2 rounded-lg ${
                      activeSection === 'resources'
                        ? 'bg-indigo-100 text-indigo-700'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    <FileText className="h-5 w-5" />
                    <span>Resources</span>
                  </button>
                </div>
              </div>

              {activeSection === 'tasks' ? (
                <div className="space-y-4">
                  {tasks.map(task => (
                    <TaskCard key={task.id} task={task} />
                  ))}
                </div>
              ) : (
                <div className="space-y-4">
                  {MOCK_RESOURCES.map(resource => (
                    <div key={resource.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <FileText className="h-5 w-5 text-indigo-500" />
                        <div>
                          <h3 className="font-medium text-gray-900">{resource.title}</h3>
                          <p className="text-sm text-gray-500">{resource.type} • {resource.size}</p>
                        </div>
                      </div>
                      <a
                        href={resource.url}
                        className="flex items-center space-x-1 text-indigo-600 hover:text-indigo-700"
                      >
                        <Download className="h-5 w-5" />
                        <span className="text-sm">Download</span>
                      </a>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="space-y-8">
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Links</h2>
              <div className="space-y-2">
                <button className="w-full flex items-center space-x-2 px-4 py-2 text-left rounded-lg hover:bg-gray-100">
                  <BookOpen className="h-5 w-5 text-indigo-500" />
                  <span>Course Materials</span>
                </button>
                <button className="w-full flex items-center space-x-2 px-4 py-2 text-left rounded-lg hover:bg-gray-100">
                  <CalendarIcon className="h-5 w-5 text-indigo-500" />
                  <span>Schedule</span>
                </button>
                <button className="w-full flex items-center space-x-2 px-4 py-2 text-left rounded-lg hover:bg-gray-100">
                  <FileText className="h-5 w-5 text-indigo-500" />
                  <span>Assignments</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}