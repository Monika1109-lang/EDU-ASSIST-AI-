export interface Task {
  id: string;
  title: string;
  dueDate: Date | null;
  type: 'assignment' | 'homework' | 'project';
  completed: boolean;
}

export interface TranscriptSegment {
  id: string;
  text: string;
  timestamp: Date;
}